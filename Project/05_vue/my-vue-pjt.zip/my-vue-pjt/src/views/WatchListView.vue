<template>
  <div>
    <h2>영화 검색 출력 페이지</h2>
  </div>
</template>

<script>
export default {
  name: 'WatchList'
}
</script>

<style>

</style>